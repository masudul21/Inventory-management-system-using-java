package net.vatri.inventory.libs;

import javafx.scene.Node;

public interface IMainPane{
	public void setPage(Node view);
}